import { useId } from 'react';

type BrandMarkProps = { className?: string };

export function BrandMark({ className }: BrandMarkProps) {
  const gradientId = `kbos-mark-gradient-${useId().replace(/:/g, '')}`;
  return <svg className={className} viewBox="0 0 150 64" role="img" aria-label="KBOS">
    <defs>
      <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#9af3ff" />
        <stop offset=".45" stopColor="#12b7ff" />
        <stop offset="1" stopColor="#0754e9" />
      </linearGradient>
    </defs>
    <path d="M5 4h20v20L49 4h24L42 31l31 29H48L25 39v21H5z" fill={`url(#${gradientId})`} stroke="#89edff" strokeWidth="1.4" />
    <path d="M64 4h34c19 0 30 8 30 22 0 8-4 13-12 17 10 2 17 8 17 18 0 13-11 20-32 20H64z" fill={`url(#${gradientId})`} stroke="#89edff" strokeWidth="1.4" />
    <circle cx="98" cy="32" r="16" fill="#07172c" stroke="#119dff" strokeWidth="1.5" />
    <text x="98" y="36" textAnchor="middle" fill="#f4fbff" fontFamily="Arial, sans-serif" fontSize="10" fontWeight="700" letterSpacing=".4">OS</text>
  </svg>;
}
