import {
  Calculator, FileText, FolderOpen, Gamepad2, Globe, Presentation, Settings2, Sparkles, Store, Table2,
  type LucideIcon,
} from 'lucide-react';

export type DownloadableAppId =
  | 'calculator'
  | 'notes'
  | 'number'
  | 'numble'
  | 'google'
  | 'documents'
  | 'spreadsheet'
  | 'files'
  | 'powerdeck';
export type AppId = DownloadableAppId | 'app-store' | 'settings';
export type AppDefinition = { id: AppId; label: string; description: string; icon: LucideIcon };
export type StoreAppDefinition = AppDefinition & { id: DownloadableAppId };

export const APP_STORE_APP: AppDefinition = {
  id: 'app-store',
  label: 'App Store',
  description: 'Browse and install KBOS apps.',
  icon: Store,
};

export const SETTINGS_APP: AppDefinition = {
  id: 'settings',
  label: 'Settings',
  description: 'Set this little desktop your way.',
  icon: Settings2,
};

export const STORE_APPS: StoreAppDefinition[] = [
  { id: 'calculator', label: 'Calculator 2.0', icon: Calculator, description: 'Calculate with adjustable precision.' },
  { id: 'notes', label: 'Notes', icon: FileText, description: 'A quiet place to put a thought.' },
  { id: 'number', label: 'Number Hunt', icon: Gamepad2, description: 'Find the hidden number and earn credits.' },
  { id: 'numble', label: 'Numble', icon: Sparkles, description: 'A six-digit number guessing game.' },
  { id: 'google', label: 'Google Hub', icon: Globe, description: 'Search, Drive, Gmail, and Calendar.' },
  { id: 'documents', label: 'Documents', icon: FileText, description: 'Write and save documents on this profile.' },
  { id: 'spreadsheet', label: 'Spreadsheet', icon: Table2, description: 'Edit cells and use simple formulas.' },
  { id: 'files', label: 'Files', icon: FolderOpen, description: 'Browse your KBOS documents and projects.' },
  { id: 'powerdeck', label: 'PowerDeck', icon: Presentation, description: 'Create and present a slide deck.' },
];

export const APP_TITLES: Record<AppId, string> = {
  'app-store': 'App Store',
  calculator: 'Calculator 2.0',
  notes: 'Notes',
  number: 'Number Hunt',
  numble: 'Numble',
  google: 'Google Hub',
  documents: 'Documents',
  spreadsheet: 'Spreadsheet',
  files: 'Files',
  powerdeck: 'PowerDeck',
  settings: 'Settings',
};
