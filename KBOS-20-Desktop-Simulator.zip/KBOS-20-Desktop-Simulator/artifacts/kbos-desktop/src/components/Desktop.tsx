import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import {
  Calculator, FileText, Gamepad2, Settings2, Sparkles, Wifi, Globe,
  BatteryFull, Power, Minus, Maximize2, X, ChevronUp, Search,
  Trash2,
} from 'lucide-react';
import type { Profile } from '../lib/local-store';
import { BrandMark } from './BrandMark';
import {
  AppGlyph, CalculatorApp, GoogleHubApp, GuessingGameApp, NotesApp, NumbleApp, SettingsApp,
} from './AppWindows';

type AppId = 'calculator' | 'notes' | 'number' | 'numble' | 'google' | 'settings';
type OpenWindow = { id: number; app: AppId; minimized: boolean; maximized: boolean; x: number | null; y: number | null };
type ProfilePatch = Partial<Pick<Profile, 'notes' | 'settings' | 'credits' | 'hints'>>;
type DesktopProps = { profile: Profile; onProfileChange: (patch: ProfilePatch) => boolean; onLogout: () => void };
const catalog: { id: AppId; label: string; icon: typeof Calculator; description: string }[] = [
  { id: 'calculator', label: 'Calculator 2.0', icon: Calculator, description: 'Small sums, careful answers.' },
  { id: 'notes', label: 'Notes', icon: FileText, description: 'A quiet place to put a thought.' },
  { id: 'number', label: 'Number Hunt', icon: Gamepad2, description: 'A number is hiding in plain sight.' },
  { id: 'numble', label: 'Numble', icon: Sparkles, description: 'Six digits. Find their places.' },
  { id: 'google', label: 'Google Hub', icon: Globe, description: 'Search, Drive, Gmail, and Calendar.' },
  { id: 'settings', label: 'Settings', icon: Settings2, description: 'Set this little desktop your way.' },
];
const appTitle: Record<AppId, string> = { calculator: 'Calculator 2.0', notes: 'Notes', number: 'Number Hunt', numble: 'Numble', google: 'Google Hub', settings: 'Settings' };

function WindowsMark() {
  return <span className="windows-mark" aria-hidden="true"><i /><i /><i /><i /></span>;
}

export function Desktop({ profile, onProfileChange, onLogout }: DesktopProps) {
  const [windows, setWindows] = useState<OpenWindow[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [startOpen, setStartOpen] = useState(false);
  const [startSearch, setStartSearch] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<AppId | null>(null);
  const [time, setTime] = useState(() => new Date());
  const [nextId, setNextId] = useState(1);
  const drag = useRef<{ id: number; dx: number; dy: number } | null>(null);
  const holdTimer = useRef<number | null>(null);
  const didLongPress = useRef(false);
  const audioContext = useRef<AudioContext | null>(null);

  useEffect(() => {
    const clock = window.setInterval(() => setTime(new Date()), 15000);
    return () => window.clearInterval(clock);
  }, []);
  useEffect(() => {
    if (!profile.settings.sound) return;
    function click(event: MouseEvent) {
      if (!(event.target as HTMLElement).closest('button')) return;
      try {
        const context = audioContext.current ?? new AudioContext();
        audioContext.current = context;
        if (context.state === 'suspended') void context.resume();
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.value = 540;
        gain.gain.setValueAtTime(0.018, context.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.035);
        oscillator.connect(gain); gain.connect(context.destination);
        oscillator.start(); oscillator.stop(context.currentTime + 0.04);
      } catch { /* Audio is an optional enhancement and may be unavailable. */ }
    }
    document.addEventListener('click', click);
    return () => document.removeEventListener('click', click);
  }, [profile.settings.sound]);
  useEffect(() => {
    function move(event: globalThis.PointerEvent) {
      if (!drag.current) return;
      const { id, dx, dy } = drag.current;
      setWindows((items) => items.map((item) => item.id === id ? { ...item, x: Math.max(12, Math.min(window.innerWidth - 100, event.clientX - dx)), y: Math.max(12, Math.min(window.innerHeight - 110, event.clientY - dy)) } : item));
    }
    function up() {
      drag.current = null;
      if (holdTimer.current !== null) window.clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      if (holdTimer.current !== null) window.clearTimeout(holdTimer.current);
    };
  }, []);
  function openApp(app: AppId) {
    setDeleteTarget(null);
    const id = nextId;
    setNextId(id + 1);
    setWindows((items) => [...items, { id, app, minimized: false, maximized: false, x: null, y: null }]);
    setActiveId(id); setStartOpen(false);
  }
  function startShortcutHold(event: ReactPointerEvent<HTMLDivElement>, app: AppId) {
    if (event.button !== 0) return;
    if (holdTimer.current !== null) window.clearTimeout(holdTimer.current);
    didLongPress.current = false;
    holdTimer.current = window.setTimeout(() => {
      didLongPress.current = true;
      setDeleteTarget(app);
    }, 560);
  }
  function endShortcutHold() {
    if (holdTimer.current !== null) window.clearTimeout(holdTimer.current);
    holdTimer.current = null;
  }
  function openShortcut(app: AppId) {
    if (didLongPress.current) {
      didLongPress.current = false;
      return;
    }
    openApp(app);
  }
  function removeShortcut(app: AppId) {
    endShortcutHold();
    didLongPress.current = false;
    const hiddenApps = profile.settings.desktopHiddenApps ?? [];
    onProfileChange({ settings: { ...profile.settings, desktopHiddenApps: [...new Set([...hiddenApps, app])] } });
    setDeleteTarget(null);
  }
  function patchWindow(id: number, patch: Partial<OpenWindow>) {
    setWindows((items) => items.map((item) => item.id === id ? { ...item, ...patch } : item));
  }
  function closeWindow(id: number) {
    setWindows((items) => items.filter((item) => item.id !== id));
    setActiveId((current) => current === id ? null : current);
  }
  function focusPinnedApp(app: AppId) {
    const candidates = windows.filter((item) => item.app === app);
    const target = candidates.find((item) => !item.minimized) ?? candidates[candidates.length - 1];
    setStartOpen(false);
    if (!target) {
      openApp(app);
      return;
    }
    if (target.id === activeId && !target.minimized) {
      patchWindow(target.id, { minimized: true });
      setActiveId(null);
      return;
    }
    patchWindow(target.id, { minimized: false });
    setActiveId(target.id);
  }
  function startDrag(event: ReactPointerEvent<HTMLDivElement>, item: OpenWindow) {
    if (item.maximized || (event.target as HTMLElement).closest('button')) return;
    const rect = event.currentTarget.parentElement?.getBoundingClientRect();
    if (!rect) return;
    drag.current = { id: item.id, dx: event.clientX - rect.left, dy: event.clientY - rect.top };
    if (item.x === null || item.y === null) patchWindow(item.id, { x: rect.left, y: rect.top });
    setActiveId(item.id);
  }
  function renderApp(app: AppId) {
    if (app === 'calculator') return <CalculatorApp profile={profile} onProfileChange={onProfileChange} />;
    if (app === 'notes') return <NotesApp profile={profile} onProfileChange={onProfileChange} />;
    if (app === 'number') return <GuessingGameApp profile={profile} onProfileChange={onProfileChange} />;
    if (app === 'numble') return <NumbleApp />;
    if (app === 'google') return <GoogleHubApp />;
    if (app === 'settings') return <SettingsApp profile={profile} onProfileChange={onProfileChange} onLogout={onLogout} />;
    return null;
  }
  return <main
    className="desktop-shell"
    data-accent={profile.settings.accent}
    style={profile.settings.wallpaper ? {
      backgroundImage: `linear-gradient(112deg,rgba(2,8,20,.24),rgba(2,8,20,.06) 58%,rgba(1,8,20,.19)),url("${profile.settings.wallpaper}")`,
    } : undefined}
  >
    <nav className="desktop-icons" aria-label="Desktop applications">
      {catalog.filter((item) => !(profile.settings.desktopHiddenApps ?? []).includes(item.id)).map((item) => {
        const Icon = item.icon;
        return <div
          key={item.id}
          className={`desktop-shortcut ${deleteTarget === item.id ? 'delete-armed' : ''}`}
          onPointerDown={(event) => startShortcutHold(event, item.id)}
          onPointerUp={endShortcutHold}
          onPointerCancel={endShortcutHold}
          onPointerLeave={endShortcutHold}
          onContextMenu={(event) => { event.preventDefault(); setDeleteTarget(item.id); }}
        >
          <button className="desktop-icon" data-testid={`desktop-icon-${item.id}`} title={item.description} onClick={() => openShortcut(item.id)}>
            <span className="icon-tile"><Icon size={19} strokeWidth={1.7} /></span>{item.label}
          </button>
          <button
            className="shortcut-delete"
            data-testid={`desktop-delete-${item.id}`}
            aria-label={`Remove ${item.label} shortcut from desktop`}
            title="Remove shortcut from desktop"
            onPointerDown={(event) => event.stopPropagation()}
            onClick={() => removeShortcut(item.id)}
          ><Trash2 size={13} /></button>
        </div>;
      })}
    </nav>
    {windows.filter((item) => !item.minimized).map((item, index) => <section
      key={item.id}
      className="window"
      data-testid={`window-${item.app}-${item.id}`}
      onPointerDown={() => setActiveId(item.id)}
      style={{
        zIndex: activeId === item.id ? 15 : 10 + index,
        ...(item.maximized ? { left: 12, top: 12, width: 'calc(100vw - 24px)', height: 'calc(100dvh - 94px)', transform: 'none', borderRadius: 12 } : {}),
        ...(item.x !== null && item.y !== null && !item.maximized ? { left: item.x, top: item.y, transform: 'none' } : {}),
      }}
    >
      <div className="window-titlebar" onPointerDown={(event) => startDrag(event, item)}>
        <div className="window-title"><AppGlyph app={item.app} size={15} />{appTitle[item.app]}</div>
        <div className="window-controls">
          <button className="window-control" data-testid={`button-minimize-${item.id}`} aria-label="Minimize window" onClick={() => patchWindow(item.id, { minimized: true })}><Minus size={13} /></button>
          <button className="window-control" data-testid={`button-maximize-${item.id}`} aria-label={item.maximized ? 'Restore window' : 'Maximize window'} onClick={() => patchWindow(item.id, { maximized: !item.maximized, x: null, y: null })}><Maximize2 size={12} /></button>
          <button className="window-control close" data-testid={`button-close-${item.id}`} aria-label="Close window" onClick={() => closeWindow(item.id)}><X size={13} /></button>
        </div>
      </div>
      <div className="window-content">{renderApp(item.app)}</div>
    </section>)}
    {startOpen && <div className="start-menu">
      <div className="start-menu-head"><BrandMark className="kbos-mark menu-brand-mark" /><div><strong>KBOS 2.0</strong><small>Computer desktop</small></div></div>
      <label className="start-search">
        <Search size={15} aria-hidden="true" />
        <input data-testid="input-start-search" aria-label="Search apps" placeholder="Search apps" value={startSearch} onChange={(event) => setStartSearch(event.target.value)} />
      </label>
      <div className="start-menu-section"><strong>{startSearch ? 'Search results' : 'Pinned apps'}</strong><span>{catalog.filter((item) => `${item.label} ${item.description}`.toLowerCase().includes(startSearch.toLowerCase())).length} apps</span></div>
      <div className="start-apps">{catalog.filter((item) => `${item.label} ${item.description}`.toLowerCase().includes(startSearch.toLowerCase())).map((item) => {
        const Icon = item.icon;
        return <button key={item.id} className="start-entry" data-testid={`start-app-${item.id}`} onClick={() => openApp(item.id)}><span className="start-icon"><Icon size={16} /></span><span><strong>{item.label}</strong><small>{item.description}</small></span></button>;
      })}</div>
      {catalog.filter((item) => `${item.label} ${item.description}`.toLowerCase().includes(startSearch.toLowerCase())).length === 0 && <div className="start-empty">No apps match that search.</div>}
      <div className="start-footer"><span>{profile.username}</span><button data-testid="button-start-logout" onClick={onLogout}><Power size={14} /> Log out</button></div>
    </div>}
    <footer className="taskbar">
      <div className="taskbar-center">
        <button className={`start-button ${startOpen ? 'active' : ''}`} data-testid="button-start-menu" aria-label="Open Start menu" title="Start" onClick={() => setStartOpen((open) => !open)}><WindowsMark /></button>
        <button className="task-search" data-testid="button-task-search" onClick={() => { setStartOpen(true); setStartSearch(''); }}><Search size={14} /><span>Search</span></button>
        <div className="task-divider" />
        <div className="task-apps">{catalog.map((item) => {
          const isRunning = windows.some((windowItem) => windowItem.app === item.id);
          const isActive = windows.some((windowItem) => windowItem.app === item.id && windowItem.id === activeId && !windowItem.minimized);
          return <button key={item.id} className={`task-app ${isActive ? 'active' : ''} ${isRunning ? 'running' : ''}`} data-testid={`task-app-${item.id}`} aria-label={`${item.label} pinned app`} title={item.label} onClick={() => focusPinnedApp(item.id)}><AppGlyph app={item.id} /></button>;
        })}</div>
      </div>
      <div className="task-right"><span className="network-label" style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Wifi size={14} /> Local</span><BatteryFull size={16} /><span className="task-clock">{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span><button className="account-chip" data-testid="button-task-account" onClick={() => openApp('settings')} title="Account settings"><span className="avatar-chip">{profile.username.slice(0, 1).toUpperCase()}</span><span className="network-label">{profile.username}</span><ChevronUp size={12} /></button><button className="window-control" data-testid="button-task-logout" aria-label="Log out" onClick={onLogout}><Power size={14} /></button></div>
    </footer>
  </main>;
}
