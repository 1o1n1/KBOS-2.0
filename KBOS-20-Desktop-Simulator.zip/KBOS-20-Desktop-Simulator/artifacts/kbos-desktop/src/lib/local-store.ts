import type { DownloadableAppId } from './apps';

export type Note = { id: string; title: string; body: string; updatedAt: number };
export type DocumentFile = { id: string; name: string; content: string; updatedAt: number };
export type SpreadsheetFile = { id: string; name: string; cells: Record<string, string>; updatedAt: number };
export type PowerDeckSlide = { id: string; title: string; body: string };
export type PowerDeckFile = { id: string; name: string; slides: PowerDeckSlide[]; updatedAt: number };
export type Settings = {
  accent: string;
  decimalPlaces: number;
  sound: boolean;
  wallpaper?: string | null;
  desktopHiddenApps?: string[];
};
export type Profile = {
  username: string;
  salt: string;
  passwordHash: string;
  notes: Note[];
  installedApps?: DownloadableAppId[];
  documents?: DocumentFile[];
  spreadsheets?: SpreadsheetFile[];
  powerDecks?: PowerDeckFile[];
  settings: Settings;
  credits: number;
  hints: string[];
};
export type ProfilePatch = Partial<Pick<Profile,
  'notes' | 'settings' | 'credits' | 'hints' | 'installedApps' | 'documents' | 'spreadsheets' | 'powerDecks'
>>;
type Database = { profiles: Record<string, Profile> };
const DB_KEY = 'kbos.local.profiles.v2';
const LAST_PROFILE_KEY = 'kbos.local.last-profile.v2';

export function readProfiles(): Record<string, Profile> {
  try {
    const raw = localStorage.getItem(DB_KEY);
    return raw ? (JSON.parse(raw) as Database).profiles || {} : {};
  } catch {
    return {};
  }
}
export function writeProfiles(profiles: Record<string, Profile>) {
  localStorage.setItem(DB_KEY, JSON.stringify({ profiles }));
}
export function readLastProfileKey() {
  try { return localStorage.getItem(LAST_PROFILE_KEY); }
  catch { return null; }
}
export function writeLastProfileKey(key: string) {
  try { localStorage.setItem(LAST_PROFILE_KEY, key); }
  catch { /* Remembering the selected profile is optional when storage is unavailable. */ }
}
function bytesToHex(bytes: Uint8Array) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
}
export async function makePasswordHash(password: string, salt: string) {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: encoder.encode(salt), iterations: 120000, hash: 'SHA-256' },
    key,
    256,
  );
  return bytesToHex(new Uint8Array(bits));
}
export function createSalt() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return bytesToHex(bytes);
}
export function freshProfile(username: string, salt: string, passwordHash: string): Profile {
  return {
    username, salt, passwordHash, notes: [], installedApps: [], documents: [], spreadsheets: [], powerDecks: [],
    settings: { accent: 'aqua', decimalPlaces: 2, sound: false, wallpaper: null, desktopHiddenApps: [] },
    credits: 0, hints: [],
  };
}
