import { useEffect, useRef, useState, type FormEvent, type ChangeEvent } from 'react';
import {
  Calculator as CalculatorIcon, CalendarDays, CircleHelp, ExternalLink, FileSpreadsheet, FileText, FolderOpen, Gamepad2,
  Globe, HardDrive, Mail, Presentation, Search, Settings2, Sparkles, RefreshCw, Plus, Store, Table2,
  Trash2, Save, Timer, ImagePlus, RotateCcw,
} from 'lucide-react';
import type { Note, Profile, ProfilePatch, Settings } from '../lib/local-store';
import { compressWallpaper } from '../lib/wallpaper';
import { BrandMark } from './BrandMark';

type Props = { profile: Profile; onProfileChange: (patch: ProfilePatch) => boolean };

export function CalculatorApp({ profile, onProfileChange }: Props) {
  const [display, setDisplay] = useState('0');
  const [stored, setStored] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [fresh, setFresh] = useState(false);
  const [expression, setExpression] = useState('');
  const [feedback, setFeedback] = useState('');
  const digits = profile.settings.decimalPlaces;
  function key(value: string) {
    setFeedback('');
    if (/\d/.test(value)) {
      setDisplay((current) => fresh || current === '0' ? value : current.length < 14 ? current + value : current);
      setFresh(false); return;
    }
    if (value === '.') {
      if (fresh) setDisplay('0.');
      else setDisplay((current) => current.includes('.') ? current : current + '.');
      setFresh(false); return;
    }
    if (value === 'AC') { setDisplay('0'); setStored(null); setOperation(null); setExpression(''); setFresh(false); return; }
    if (value === '±') { setDisplay((current) => String(Number(current) * -1)); return; }
    if (value === '%') { setDisplay((current) => String(Number(current) / 100)); return; }
    if (value === '=') {
      if (stored === null || !operation) return;
      const left = stored; const right = Number(display);
      const result = operation === '+' ? left + right : operation === '−' ? left - right : operation === '×' ? left * right : right === 0 ? NaN : left / right;
      if (!Number.isFinite(result)) { setDisplay('Error'); setFeedback('Cannot divide by zero. Clear to start again.'); }
      else {
        const rounded = Number(result.toFixed(digits));
        setDisplay(String(rounded)); setExpression(`${left} ${operation} ${right} =`); setFeedback('');
      }
      setStored(null); setOperation(null); setFresh(true); return;
    }
    if (stored !== null && operation && !fresh) key('=');
    setStored(Number(display)); setOperation(value); setExpression(`${display} ${value}`); setFresh(true);
  }
  const keys = ['AC', '±', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '0', '.', '='];
  return <div className="calc">
    <div className="calc-display"><div className="calc-expression">{expression || 'Calculator 2.0'}</div><div className="calc-value" data-testid="text-calculator-display">{display}</div></div>
    <div className="calc-grid">{keys.map((item) => <button key={item} data-testid={`button-calc-${item === '÷' ? 'divide' : item === '×' ? 'multiply' : item === '−' ? 'subtract' : item === '+' ? 'add' : item === '=' ? 'equals' : item === 'AC' ? 'clear' : item}`} className={`calc-key ${['÷', '×', '−', '+'].includes(item) ? 'operator' : ''} ${item === '=' ? 'equals' : ''}`} onClick={() => key(item)}>{item}</button>)}</div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 15 }}>
      <label htmlFor="calc-decimals" className="muted" style={{ fontSize: 10 }}>Decimal places</label>
      <input id="calc-decimals" data-testid="input-decimal-places" type="range" min="0" max="8" value={digits} onChange={(event) => onProfileChange({ settings: { ...profile.settings, decimalPlaces: Number(event.target.value) } })} />
      <span style={{ font: '11px var(--app-font-mono)', color: '#c7d7e0' }}>{digits}</span>
    </div>
    <div className="inline-feedback" role="status">{feedback}</div>
  </div>;
}

export function NotesApp({ profile, onProfileChange, initialFileId }: Props & { initialFileId?: string }) {
  const [activeId, setActiveId] = useState<string | null>(initialFileId ?? profile.notes[0]?.id ?? null);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [message, setMessage] = useState('');
  const active = profile.notes.find((note) => note.id === activeId);
  useEffect(() => {
    setTitle(active?.title ?? '');
    setBody(active?.body ?? '');
  }, [activeId]); // switching note loads its saved content
  useEffect(() => {
    if (initialFileId) setActiveId(initialFileId);
  }, [initialFileId]);
  function createNote() {
    const note: Note = { id: crypto.randomUUID(), title: 'Untitled note', body: '', updatedAt: Date.now() };
    onProfileChange({ notes: [note, ...profile.notes] });
    setActiveId(note.id); setMessage('A new note is ready.');
  }
  function saveNote() {
    if (!active) return;
    const notes = profile.notes.map((note) => note.id === active.id ? { ...note, title: title.trim() || 'Untitled note', body, updatedAt: Date.now() } : note);
    onProfileChange({ notes }); setMessage('Saved to this browser.');
  }
  function deleteNote() {
    if (!active) return;
    const remaining = profile.notes.filter((note) => note.id !== active.id);
    onProfileChange({ notes: remaining });
    setActiveId(remaining[0]?.id ?? null); setMessage('Note removed.');
  }
  return <div className="notes-layout">
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <button className="button small" data-testid="button-note-new" onClick={createNote} style={{ marginBottom: 8 }}><Plus size={13} /> New note</button>
      <div className="notes-list">
        {profile.notes.map((note) => <button key={note.id} data-testid={`button-note-${note.id}`} onClick={() => { setActiveId(note.id); setMessage(''); }} className={`note-row ${note.id === activeId ? 'active' : ''}`}>
          <strong>{note.title || 'Untitled note'}</strong><span>{new Date(note.updatedAt).toLocaleDateString()}</span>
        </button>)}
        {!profile.notes.length && <div className="muted" style={{ fontSize: 10, padding: 8 }}>Your notes will live here.</div>}
      </div>
    </div>
    {active ? <div className="notes-editor">
      <input className="field" data-testid="input-note-title" value={title} onChange={(event) => setTitle(event.target.value)} aria-label="Note title" placeholder="Untitled note" />
      <textarea className="field textarea" data-testid="input-note-body" value={body} onChange={(event) => setBody(event.target.value)} aria-label="Note body" placeholder="Start with a thought…" />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div className="inline-feedback" role="status">{message}</div>
        <div style={{ display: 'flex', gap: 7 }}>
          <button className="button danger small" data-testid="button-note-delete" onClick={deleteNote} aria-label="Delete note"><Trash2 size={13} /></button>
          <button className="button small" data-testid="button-note-save" onClick={saveNote}><Save size={13} /> Save</button>
        </div>
      </div>
    </div> : <div className="empty-state"><FileText size={27} /><strong>No note selected</strong><span>Create a note to keep something close.</span></div>}
  </div>;
}

export function GuessingGameApp({ profile, onProfileChange }: Props) {
  const [secret, setSecret] = useState(() => 1 + Math.floor(Math.random() * 100));
  const [maximum, setMaximum] = useState(100);
  const [rangeInput, setRangeInput] = useState('100');
  const [guess, setGuess] = useState('');
  const [history, setHistory] = useState<{ value: number; result: string }[]>([]);
  const [message, setMessage] = useState('A number from 1 to 100 is waiting.');
  const [won, setWon] = useState(false);
  const [revealed, setRevealed] = useState('');
  const [hintUsed, setHintUsed] = useState(false);
  function startOver() {
    const nextMaximum = Number(rangeInput);
    if (!Number.isSafeInteger(nextMaximum) || nextMaximum < 1) {
      setMessage('Choose a whole-number maximum greater than zero.');
      return;
    }
    setMaximum(nextMaximum);
    setSecret(1 + Math.floor(Math.random() * nextMaximum));
    setGuess('');
    setHistory([]);
    setMessage(`A number from 1 to ${nextMaximum} is waiting.`);
    setWon(false);
    setRevealed('');
    setHintUsed(false);
  }
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = Number(guess);
    if (!Number.isSafeInteger(value) || value < 1 || value > maximum) { setMessage(`Enter a whole number between 1 and ${maximum}.`); return; }
    const result = value === secret ? 'Found it' : value < secret ? 'Too low' : 'Too high';
    setHistory((items) => [{ value, result }, ...items]); setGuess('');
    if (value === secret) {
      setWon(true); setMessage('Right on. 10 credits added to your balance.');
      onProfileChange({ credits: profile.credits + 10 });
    } else setMessage(`${result}. Give it another thought.`);
  }
  function buyHint() {
    if (profile.credits < 5) { setMessage('Not enough credits. A hint costs 5 credits.'); return; }
    onProfileChange({ credits: profile.credits - 5, hints: [...profile.hints, 'parity'] });
    setMessage('Clue added to your pocket.');
  }
  function useHint() {
    if (hintUsed) return;
    setRevealed(`The hidden number is ${secret % 2 ? 'odd' : 'even'}.`);
    setHintUsed(true);
    const hintIndex = profile.hints.indexOf('parity');
    if (hintIndex >= 0) onProfileChange({ hints: profile.hints.filter((_, index) => index !== hintIndex) });
  }
  return <div>
    <div className="game-hero">
      <div><div className="section-kicker">A little game of nerve</div><h2 className="app-heading">Number Hunt</h2><p className="app-subtitle">Find the hidden number, collect a few credits.</p></div>
      <div className="credit-pill">◈ {profile.credits} credits</div>
    </div>
    <div className="settings-row" style={{ marginTop: 18, padding: '10px 0' }}>
      <div><strong>Maximum number</strong><span>Pick the upper end of the range</span></div>
      <input className="field" data-testid="input-guess-maximum" type="number" min="1" step="1" value={rangeInput} onChange={(event) => setRangeInput(event.target.value)} aria-label="Maximum number" style={{ width: 96, minHeight: 36 }} />
    </div>
    <form onSubmit={submit} style={{ display: 'flex', gap: 8, margin: '22px 0 5px' }}>
      <input className="field" data-testid="input-guess" type="number" min="1" max={maximum} value={guess} onChange={(event) => setGuess(event.target.value)} placeholder={`Pick a number, 1–${maximum}`} disabled={won} />
      <button className="button" data-testid="button-guess-submit" disabled={won}>Try</button>
      <button className="button secondary" type="button" data-testid="button-guess-reset" onClick={startOver} aria-label="Start a new round"><RefreshCw size={15} /></button>
    </form>
    <div className="inline-feedback" role="status">{message}</div>
    {revealed && <div className="hint-card" data-testid="text-game-hint">{revealed}</div>}
    <div className="soft-panel" style={{ padding: 14, marginTop: 10 }}>
      <div className="section-kicker" style={{ marginBottom: 9 }}>Recent attempts</div>
      {history.length ? <div className="guess-history">{history.slice(0, 5).map((item, index) => <div className="guess-line" key={`${item.value}-${index}`}><span>{String(item.value).padStart(2, '0')}</span><span>{item.result}</span></div>)}</div> : <div className="muted" style={{ fontSize: 11 }}>No guesses yet. Make the first move.</div>}
    </div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 7, margin: '19px 0 9px', color: '#e6d5a8', fontSize: 11, fontWeight: 700 }}><Sparkles size={14} /> Hint shop</div>
    <div className="shop-item">
      <div><strong style={{ fontSize: 11 }}>Odd or even?</strong><p>Reveal whether the hidden number is odd or even. One hint per round.</p></div>
      {profile.hints.includes('parity')
        ? <button className="button small" data-testid="button-hint-use-parity" onClick={useHint} disabled={hintUsed}>{hintUsed ? 'Used' : 'Reveal'}</button>
        : <button className="button secondary small" data-testid="button-hint-buy-parity" onClick={buyHint}>5 cr</button>}
    </div>
  </div>;
}

function makeSecret() { return Array.from({ length: 6 }, () => String(1 + Math.floor(Math.random() * 9))).join(''); }
export function NumbleApp() {
  const [mode, setMode] = useState<'normal' | 'hard'>('normal');
  const [secret, setSecret] = useState(makeSecret);
  const [guess, setGuess] = useState('');
  const [attempts, setAttempts] = useState<{ guess: string; matched: boolean[] }[]>([]);
  const [won, setWon] = useState(false);
  const [seconds, setSeconds] = useState(30);
  const [message, setMessage] = useState('Six digits. Every digit is between 1 and 9.');
  const finished = won || (mode === 'hard' && seconds <= 0);
  useEffect(() => {
    if (mode !== 'hard' || won || seconds <= 0) return;
    const timer = window.setInterval(() => setSeconds((value) => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [mode, won, seconds]);
  function newGame(nextMode = mode) {
    setMode(nextMode); setSecret(makeSecret()); setGuess(''); setAttempts([]); setWon(false); setSeconds(30);
    setMessage(nextMode === 'hard' ? 'Thirty seconds. No room for second thoughts.' : 'Six digits. Every digit is between 1 and 9.');
  }
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!/^[1-9]{6}$/.test(guess)) { setMessage('Use exactly six digits, each from 1 to 9.'); return; }
    const matched = Array.from(guess, (digit, index) => digit === secret[index]);
    const exact = matched.every(Boolean);
    setAttempts((items) => [{ guess, matched }, ...items]); setGuess('');
    if (exact) { setWon(true); setMessage('Every digit in its place. Nicely done.'); }
    else setMessage(`${matched.filter(Boolean).length} digit${matched.filter(Boolean).length === 1 ? '' : 's'} in the right position. Those places stay lit below.`);
  }
  return <div>
    <div className="game-hero">
      <div><div className="section-kicker">Six places. One sequence.</div><h2 className="app-heading">Numble</h2><p className="app-subtitle">Correctly placed digits are revealed after each try.</p></div>
      {mode === 'hard' && <div className="numble-clock"><Timer size={14} style={{ verticalAlign: 'middle', marginRight: 5 }} />00:{String(seconds).padStart(2, '0')}</div>}
    </div>
    <div style={{ display: 'flex', gap: 7, marginTop: 18 }}>
      <button className={`button small ${mode === 'normal' ? '' : 'secondary'}`} data-testid="button-numble-normal" onClick={() => newGame('normal')}>Normal</button>
      <button className={`button small ${mode === 'hard' ? '' : 'secondary'}`} data-testid="button-numble-hard" onClick={() => newGame('hard')}>Hard · 30 sec</button>
    </div>
    <div className="numble-slots" aria-label="Guess six digits">
      {Array.from({ length: 6 }, (_, index) => <div className="numble-slot" key={index}>{guess[index] || <span style={{ color: '#536b7c' }}>·</span>}</div>)}
    </div>
    {attempts.length > 0 && <div className="numble-slots" aria-label="Correctly positioned digits">
      {Array.from({ length: 6 }, (_, index) => {
        const confirmed = attempts.some((attempt) => attempt.matched[index]);
        const revealed = confirmed ? secret[index] : '';
        return <div key={index} className={`numble-slot ${revealed ? 'correct' : 'locked'}`}>{revealed || '·'}</div>;
      })}
    </div>}
    <form onSubmit={submit} style={{ display: 'flex', gap: 8 }}>
      <input className="field" data-testid="input-numble-guess" inputMode="numeric" maxLength={6} value={guess} disabled={finished} onChange={(event) => setGuess(event.target.value.replace(/[^1-9]/g, '').slice(0, 6))} placeholder="Enter six digits from 1–9" />
      <button className="button" data-testid="button-numble-submit" disabled={finished}>Check</button>
    </form>
    <div className="inline-feedback" role="status">{mode === 'hard' && seconds === 0 && !won ? 'Time is up. Start a new round to try again.' : message}</div>
    <div className="soft-panel" style={{ padding: 14, marginTop: 6 }}>
      <div className="section-kicker" style={{ marginBottom: 8 }}>Guess history</div>
      {attempts.length ? <div className="guess-history">{attempts.slice(0, 4).map((attempt, index) => <div className="guess-line" key={`${attempt.guess}-${index}`}><span>{attempt.guess.split('').map((digit, position) => <span key={position} style={{ color: attempt.matched[position] ? '#86e6d2' : '#c5d5e1' }}>{digit}</span>)}</span><span>{attempt.matched.filter(Boolean).length}/6 placed</span></div>)}</div> : <div className="muted" style={{ fontSize: 11 }}>Your guesses will appear here.</div>}
    </div>
  </div>;
}

export function SettingsApp({ profile, onProfileChange, onLogout }: Props & { onLogout: () => void }) {
  const settings = profile.settings;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const wallpaperInput = useRef<HTMLInputElement>(null);
  const [wallpaperBusy, setWallpaperBusy] = useState(false);
  const [wallpaperFeedback, setWallpaperFeedback] = useState<{ kind: 'success' | 'error'; text: string } | null>(null);
  const [updatesOpen, setUpdatesOpen] = useState(false);
  function update(values: Partial<Settings>) { return onProfileChange({ settings: { ...settingsRef.current, ...values } }); }
  async function chooseWallpaper(event: ChangeEvent<HTMLInputElement>) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;
    setWallpaperBusy(true);
    setWallpaperFeedback(null);
    try {
      const wallpaper = await compressWallpaper(file);
      const saved = update({ wallpaper });
      setWallpaperFeedback(saved
        ? { kind: 'success', text: 'Wallpaper saved to this profile.' }
        : { kind: 'error', text: 'Wallpaper applied for this session, but browser storage could not save it.' });
    } catch (error) {
      setWallpaperFeedback({ kind: 'error', text: error instanceof Error ? error.message : 'Could not use that image.' });
    } finally {
      setWallpaperBusy(false);
      input.value = '';
    }
  }
  function resetWallpaper() {
    const saved = update({ wallpaper: null });
    setWallpaperFeedback(saved
      ? { kind: 'success', text: 'The default KBOS wallpaper is back.' }
      : { kind: 'error', text: 'The default was applied for this session, but browser storage could not save it.' });
  }
  const accents = [{ id: 'aqua', color: '#65d9df' }, { id: 'citrus', color: '#d9ce7b' }, { id: 'coral', color: '#e99382' }];
  const hiddenDesktopApps = settings.desktopHiddenApps ?? [];
  return <div>
    <div className="section-kicker">Personalize your session</div><h2 className="app-heading">Settings</h2><p className="app-subtitle">A few switches to make this place feel like yours.</p>
    <section className="settings-wallpaper" aria-label="Desktop wallpaper">
      <div
        className="settings-wallpaper-preview"
        role="img"
        aria-label={settings.wallpaper ? 'Selected desktop wallpaper preview' : 'Default KBOS wallpaper preview'}
        style={settings.wallpaper ? { backgroundImage: `linear-gradient(rgba(4,12,25,.12),rgba(4,12,25,.12)),url("${settings.wallpaper}")` } : undefined}
      >
        <BrandMark className="kbos-mark wallpaper-preview-logo" />
        <div className="wallpaper-preview-taskbar"><span /><i /><i /><i /></div>
      </div>
      <div className="settings-wallpaper-details">
        <div><strong>Desktop background</strong><span>Choose an image from your files. It is saved with this profile.</span></div>
        <div className="settings-wallpaper-actions">
          <input ref={wallpaperInput} className="wallpaper-file-input" type="file" accept="image/png,image/jpeg,image/webp" data-testid="input-wallpaper-file" onChange={chooseWallpaper} tabIndex={-1} aria-hidden="true" />
          <button className="button small" type="button" data-testid="button-wallpaper-choose" onClick={() => wallpaperInput.current?.click()} disabled={wallpaperBusy}>
            <ImagePlus size={14} />{wallpaperBusy ? 'Preparing…' : 'Choose image'}
          </button>
          {settings.wallpaper && <button className="button secondary small" type="button" data-testid="button-wallpaper-reset" onClick={resetWallpaper}>
            <RotateCcw size={13} />KBOS default
          </button>}
        </div>
        <p className="wallpaper-hint">PNG, JPG, or WebP · compressed and stored in this browser</p>
        {wallpaperFeedback && <p className={`wallpaper-feedback ${wallpaperFeedback.kind}`} role="status" data-testid="status-wallpaper">{wallpaperFeedback.text}</p>}
      </div>
    </section>
    <div className="settings-row"><div><strong>Accent color</strong><span>Choose a highlight for your workspace</span></div>
      <div style={{ display: 'flex', gap: 8 }}>{accents.map((accent) => <button key={accent.id} data-testid={`button-accent-${accent.id}`} aria-label={`${accent.id} accent`} onClick={() => update({ accent: accent.id })} style={{ width: 27, height: 27, borderRadius: 99, border: settings.accent === accent.id ? '2px solid white' : '1px solid rgba(255,255,255,.28)', background: accent.color, boxShadow: settings.accent === accent.id ? '0 0 0 3px rgba(255,255,255,.12)' : 'none' }} />)}</div>
    </div>
    <div className="settings-row"><div><strong>Button sounds</strong><span>Soft interface clicks when enabled</span></div><button className={`switch ${settings.sound ? 'on' : ''}`} data-testid="button-toggle-sound" onClick={() => update({ sound: !settings.sound })} aria-label="Toggle button sounds" aria-pressed={settings.sound} /></div>
    <div className="settings-row"><div><strong>Calculator precision</strong><span>Default decimal places for results</span></div><select className="field" data-testid="select-decimals" value={settings.decimalPlaces} onChange={(event) => update({ decimalPlaces: Number(event.target.value) })} style={{ width: 100, minHeight: 36 }}>{Array.from({ length: 9 }, (_, index) => <option key={index} value={index}>{index} places</option>)}</select></div>
    <div className="settings-row"><div><strong>Profile storage</strong><span>Saved only in this browser on this device</span></div><span style={{ color: '#80d9d8' }}>LOCAL</span></div>
    <div className="settings-row">
      <div><strong>Desktop shortcuts</strong><span>{hiddenDesktopApps.length ? `${hiddenDesktopApps.length} hidden. They remain available from Start.` : 'Press and hold an installed app to remove its shortcut. App Store stays available.'}</span></div>
      {hiddenDesktopApps.length > 0 && <button className="button secondary small" type="button" data-testid="button-restore-shortcuts" onClick={() => update({ desktopHiddenApps: [] })}>Restore all</button>}
    </div>
    <div className="settings-row">
      <div><strong>Update log</strong><span>See what has changed in KBOS.</span></div>
      <button className="button secondary small" type="button" data-testid="button-settings-updates" aria-expanded={updatesOpen} onClick={() => setUpdatesOpen((open) => !open)}>
        <RefreshCw size={13} />{updatesOpen ? 'Hide updates' : 'View updates'}
      </button>
    </div>
    {updatesOpen && <div className="settings-updates" data-testid="settings-update-log"><UpdatesApp embedded /></div>}
    <div style={{ marginTop: 23, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div><div className="section-kicker">Session</div><div style={{ marginTop: 4, color: '#9fb3c2', fontSize: 11 }}>Signed in as <strong style={{ color: '#dfeaf0' }}>{profile.username}</strong></div></div>
      <button className="button danger small" data-testid="button-settings-logout" onClick={onLogout}>Log out</button>
    </div>
  </div>;
}

export function UpdatesApp({ embedded = false }: { embedded?: boolean } = {}) {
  const updates = [
    { date: '10.12.2026', title: 'App Store & productivity apps', text: 'Install apps from the App Store and create local Documents, Spreadsheet files, and PowerDeck presentations. Uninstalling an app keeps your saved files.' },
    { date: '10.12.2026', title: 'Google Hub', text: 'Search Google or open Drive, Gmail, and Calendar from one place. Google handles sign-in on its own pages; KBOS does not read your service data.' },
    { date: '10.12.2026', title: 'Personalize the desktop', text: 'Choose a picture from your files for the KBOS wallpaper, remove desktop shortcuts with a press-and-hold, and find this update log in Settings.' },
    { date: '10.11.2026', title: 'KBOS 2.0 — A fresh boot', text: 'The desktop gets separate app windows, local profiles, a calculator with adjustable precision, and settings that stick around.' },
    { date: '10.11.2026', title: 'KBOS 1.1 — More to explore', text: 'Numble and Notes join the app menu, alongside quality-of-life interface fixes.' },
    { date: '10.09.2026', title: 'Calculator 2.0', text: 'Choose how many decimal places to show, start a fresh calculation, and enjoy a few interface fixes.' },
    { date: '10.09.2026', title: 'KBOS 1.0 — Credits and clues', text: 'The RNG game adds a credit system, a 5-credit even-or-odd hint shop, and improved navigation.' },
  ];
  return <div className={embedded ? 'embedded-update-log' : undefined}>
    {!embedded && <><div className="section-kicker">The little things that changed</div><h2 className="app-heading">Update log</h2><p className="app-subtitle">A short record of this curious little system.</p></>}
    <div className="update-list">{updates.map((item) => <article className="update-row" key={`${item.date}-${item.title}`}><time>{item.date}</time><div><strong>{item.title}</strong><p>{item.text}</p></div></article>)}</div>
    {!embedded && <div className="soft-panel" style={{ padding: 12, display: 'flex', gap: 9, alignItems: 'center', marginTop: 18, color: '#a8bdca', fontSize: 10 }}><CircleHelp size={15} color="#70d4d9" />Everything runs locally. No account data leaves this browser.</div>}
  </div>;
}

export function GoogleHubApp() {
  const services = [
    { label: 'Google Drive', description: 'Files and documents', href: 'https://drive.google.com/', icon: HardDrive, tone: 'drive' },
    { label: 'Gmail', description: 'Email and messages', href: 'https://mail.google.com/', icon: Mail, tone: 'gmail' },
    { label: 'Google Calendar', description: 'Events and schedules', href: 'https://calendar.google.com/', icon: CalendarDays, tone: 'calendar' },
  ];
  return <div className="google-hub">
    <div className="google-hub-heading">
      <span className="google-hub-mark" aria-hidden="true">G</span>
      <div><div className="section-kicker">GOOGLE SERVICES</div><h2 className="app-heading">Google Hub</h2><p className="app-subtitle">Search the web or open a Google service.</p></div>
    </div>
    <form className="google-search" action="https://www.google.com/search" method="get" target="_blank" rel="noopener noreferrer">
      <Search size={17} aria-hidden="true" />
      <input type="search" name="q" aria-label="Search Google" placeholder="Search Google" required />
      <button className="button small" type="submit">Search <ExternalLink size={13} /></button>
    </form>
    <div className="google-services">
      {services.map(({ label, description, href, icon: Icon, tone }) => <a className="google-service" href={href} target="_blank" rel="noopener noreferrer" key={label}>
        <span className={`google-service-icon ${tone}`}><Icon size={19} /></span>
        <span className="google-service-copy"><strong>{label}</strong><small>{description}</small></span>
        <ExternalLink className="google-service-external" size={14} aria-hidden="true" />
      </a>)}
    </div>
    <div className="google-hub-note"><Globe size={15} aria-hidden="true" /><span>These open Google’s official pages in a new tab. Sign in with Google there if prompted; KBOS does not store your Google password or read your account data.</span></div>
  </div>;
}

export function AppGlyph({ app, size = 17 }: { app: string; size?: number }) {
  const icons: Record<string, typeof CalculatorIcon> = {
    'app-store': Store, calculator: CalculatorIcon, notes: FileText, number: Gamepad2, numble: Sparkles, google: Globe,
    documents: FileText, spreadsheet: Table2, files: FolderOpen, powerdeck: Presentation,
    settings: Settings2, updates: RefreshCw,
  };
  const Icon = icons[app] ?? FileText;
  return <Icon size={size} />;
}
