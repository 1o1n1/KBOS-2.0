const MAX_SOURCE_BYTES = 16 * 1024 * 1024;
const MAX_DATA_URL_CHARS = 950_000;
const MAX_DIMENSION = 1920;

export async function compressWallpaper(file: File): Promise<string> {
  if (file.size > MAX_SOURCE_BYTES) {
    throw new Error('Choose an image smaller than 16 MB.');
  }
  const supported = ['image/png', 'image/jpeg', 'image/webp'];
  const hasSupportedExtension = /\.(png|jpe?g|webp)$/i.test(file.name);
  if (!supported.includes(file.type) && !hasSupportedExtension) {
    throw new Error('Choose a PNG, JPG, or WebP image.');
  }

  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error('KBOS could not open that image. Try a PNG, JPG, or WebP file.');
  }

  try {
    if (bitmap.width * bitmap.height > 32_000_000) {
      throw new Error('That image has too many pixels. Try a smaller image.');
    }
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    if (!context) throw new Error('KBOS could not prepare that image.');

    let scale = Math.min(1, MAX_DIMENSION / bitmap.width, MAX_DIMENSION / bitmap.height);
    for (const quality of [0.84, 0.76, 0.68, 0.6, 0.54]) {
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      context.fillStyle = '#061126';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', quality);
      if (dataUrl.length <= MAX_DATA_URL_CHARS) return dataUrl;
      scale *= 0.8;
    }
    throw new Error('That image is still too large after compression. Try a smaller image.');
  } finally {
    bitmap.close();
  }
}
