import { useEffect, useState, type FormEvent } from 'react';
import { ArrowRight, KeyRound, UserRound, UsersRound } from 'lucide-react';
import { BrandMark } from './BrandMark';

type AuthScreenProps = {
  onLogin: (username: string, password: string) => Promise<string | null>;
  onSignup: (username: string, password: string) => Promise<string | null>;
  preferredUsername: string | null;
  hasProfiles: boolean;
};

type ScreenMode = 'unlock' | 'other-user' | 'create';

export function AuthScreen({ onLogin, onSignup, preferredUsername, hasProfiles }: AuthScreenProps) {
  const [mode, setMode] = useState<ScreenMode>(() => preferredUsername ? 'unlock' : hasProfiles ? 'other-user' : 'create');
  const [username, setUsername] = useState(preferredUsername ?? '');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 30000);
    return () => window.clearInterval(timer);
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage('');
    if (mode === 'create' && password !== confirm) { setMessage('Those passwords do not match.'); return; }
    setBusy(true);
    try {
      const name = mode === 'unlock' ? preferredUsername ?? '' : username;
      const result = mode === 'create' ? await onSignup(name, password) : await onLogin(name, password);
      if (result) setMessage(result);
    } catch {
      setMessage('KBOS could not check this profile. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  function changeMode(next: ScreenMode) {
    setMode(next);
    setUsername(next === 'unlock' ? preferredUsername ?? '' : '');
    setPassword('');
    setConfirm('');
    setMessage('');
  }

  const isCreate = mode === 'create';
  const isUnlock = mode === 'unlock';
  const displayName = isUnlock ? preferredUsername : username;
  const dateLabel = now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
  const timeLabel = now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

  return <main className="lock-screen">
    <div className="lock-screen-glow" aria-hidden="true" />
    <header className="lock-topbar">
      <div className="brand-lockup"><BrandMark className="kbos-mark lock-brand-mark" /> KBOS <span style={{ color: '#9db8cc', fontWeight: 500 }}>2.0</span></div>
      <span className="lock-top-label">LOCAL DESKTOP</span>
    </header>
    <section className="lock-clock" aria-label="Current time and date">
      <div className="lock-time">{timeLabel}</div>
      <div className="lock-date">{dateLabel}</div>
      <div className="lock-clock-caption">Your KBOS desktop is ready</div>
    </section>
    <section className="lock-access">
      <div className="lock-avatar" aria-hidden="true">
        {displayName ? displayName.slice(0, 1).toUpperCase() : <UserRound size={34} strokeWidth={1.5} />}
      </div>
      <h1>{isCreate ? 'Set up KBOS' : isUnlock ? `Welcome back, ${preferredUsername}` : 'Other user'}</h1>
      <p className="lock-prompt">{isCreate ? 'Create a local profile for this desktop.' : mode === 'other-user' ? 'Enter a username and password to unlock.' : 'Enter your password to unlock.'}</p>
      <form className="lock-form" onSubmit={submit}>
        {!isUnlock && <div className="lock-field-wrap">
          <label className="field-label" htmlFor="auth-user">{isCreate ? 'Choose a username' : 'Username'}</label>
          <div className="lock-input-wrap">
            <UserRound size={16} aria-hidden="true" />
            <input id="auth-user" data-testid="input-username" className="field" autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} placeholder="e.g. orbit" minLength={3} maxLength={20} required autoFocus={mode === 'other-user'} />
          </div>
        </div>}
        <div className="lock-field-wrap">
          <label className="field-label" htmlFor="auth-pass">{isCreate ? 'Create a password' : 'Password'}</label>
          <div className="lock-input-wrap">
            <KeyRound size={16} aria-hidden="true" />
            <input id="auth-pass" data-testid="input-password" className="field" type="password" autoComplete={isCreate ? 'new-password' : 'current-password'} value={password} onChange={(event) => setPassword(event.target.value)} placeholder={isCreate ? 'At least 6 characters' : 'Enter your password'} minLength={6} required autoFocus={isUnlock} />
          </div>
        </div>
        {isCreate && <div className="lock-field-wrap">
          <label className="field-label" htmlFor="auth-confirm">Confirm password</label>
          <div className="lock-input-wrap">
            <KeyRound size={16} aria-hidden="true" />
            <input id="auth-confirm" data-testid="input-confirm-password" className="field" type="password" autoComplete="new-password" value={confirm} onChange={(event) => setConfirm(event.target.value)} placeholder="Enter it again" required />
          </div>
        </div>}
        <div className="auth-note"><strong>Local simulator.</strong> Your profile stays in this browser. This password does not secure your device like a real Windows account.</div>
        <div className="inline-feedback" role="status" data-testid="status-auth">{message}</div>
        <button className="button lock-unlock-button" data-testid="button-auth-submit" type="submit" disabled={busy}>
          {busy ? 'Checking…' : isCreate ? 'Create profile' : 'Unlock'} {!busy && <ArrowRight size={16} />}
        </button>
      </form>
      <div className="lock-actions">
        {isUnlock && <>
          <button className="auth-toggle" data-testid="button-auth-mode" type="button" onClick={() => changeMode('other-user')}><UsersRound size={14} /> Other user</button>
          <button className="auth-toggle" type="button" onClick={() => changeMode('create')}>Create a profile</button>
        </>}
        {mode === 'other-user' && <>
          {preferredUsername && <button className="auth-toggle" type="button" onClick={() => changeMode('unlock')}>Back to {preferredUsername}</button>}
          <button className="auth-toggle" type="button" onClick={() => changeMode('create')}>Create a local profile</button>
        </>}
        {isCreate && hasProfiles && <button className="auth-toggle" type="button" onClick={() => changeMode(preferredUsername ? 'unlock' : 'other-user')}>Use an existing profile</button>}
      </div>
    </section>
    <footer className="lock-footer">
      <span>KBOS 2.0 <i /> LOCAL SIMULATOR</span>
      <span>{dateLabel}</span>
    </footer>
  </main>;
}
