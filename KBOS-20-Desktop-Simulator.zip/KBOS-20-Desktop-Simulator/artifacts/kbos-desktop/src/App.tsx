import { useCallback, useEffect, useState } from 'react';
import { AuthScreen } from './components/AuthScreen';
import { Desktop } from './components/Desktop';
import {
  createSalt, freshProfile, makePasswordHash, readProfiles, readLastProfileKey,
  writeLastProfileKey, writeProfiles, type Profile, type ProfilePatch,
} from './lib/local-store';

function App() {
  const [profiles, setProfiles] = useState<Record<string, Profile>>(() => readProfiles());
  const [currentKey, setCurrentKey] = useState<string | null>(null);
  const [lastProfileKey, setLastProfileKey] = useState<string | null>(() => readLastProfileKey());
  const profile = currentKey ? profiles[currentKey] : null;
  const preferredKey = lastProfileKey && profiles[lastProfileKey]
    ? lastProfileKey
    : Object.keys(profiles).length === 1 ? Object.keys(profiles)[0] : null;
  const preferredUsername = preferredKey ? profiles[preferredKey]?.username ?? null : null;
  useEffect(() => { document.title = profile ? `KBOS 2.0 — ${profile.username}` : 'KBOS 2.0 — Local desktop'; }, [profile]);

  const saveProfiles = useCallback((next: Record<string, Profile>) => {
    setProfiles(next);
    try { writeProfiles(next); return true; }
    catch { return false; }
  }, []);
  async function signup(usernameInput: string, password: string) {
    const username = usernameInput.trim();
    const key = username.toLocaleLowerCase();
    if (!/^[a-zA-Z0-9_-]{3,20}$/.test(username)) return 'Use 3–20 letters, numbers, underscores, or hyphens.';
    if (password.length < 6) return 'Choose a password with at least 6 characters.';
    if (profiles[key]) return 'That username already has a local profile. Unlock the existing profile instead.';
    try {
      const salt = createSalt();
      const passwordHash = await makePasswordHash(password, salt);
      const next = { ...profiles, [key]: freshProfile(username, salt, passwordHash) };
      saveProfiles(next); setCurrentKey(key); setLastProfileKey(key); writeLastProfileKey(key); return null;
    } catch {
      return 'This browser could not create a secure password hash. Try a modern browser on a secure connection.';
    }
  }
  async function login(usernameInput: string, password: string) {
    const key = usernameInput.trim().toLocaleLowerCase();
    const existing = profiles[key];
    if (!existing) return 'No local profile by that name. Create one to get started.';
    try {
      const hash = await makePasswordHash(password, existing.salt);
      if (hash !== existing.passwordHash) return 'That password does not match this local profile.';
      setCurrentKey(key); setLastProfileKey(key); writeLastProfileKey(key); return null;
    } catch {
      return 'This browser could not verify the local password. Try a modern browser on a secure connection.';
    }
  }
  function updateProfile(patch: ProfilePatch) {
    if (!currentKey || !profiles[currentKey]) return false;
    return saveProfiles({ ...profiles, [currentKey]: { ...profiles[currentKey], ...patch } });
  }

  if (!profile) return <AuthScreen
    onLogin={login}
    onSignup={signup}
    preferredUsername={preferredUsername}
    hasProfiles={Object.keys(profiles).length > 0}
  />;
  return <Desktop profile={profile} onProfileChange={updateProfile} onLogout={() => setCurrentKey(null)} />;
}

export default App;
